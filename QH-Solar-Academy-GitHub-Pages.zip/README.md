# QH Solar Academy — GitHub Pages

نسخه وب/PWA پروژه QH Solar Academy برای آموزش نیروگاه خورشیدی ۱۰۰ کیلووات.

## قابلیت‌ها
- RTL / Dari
- ۸ مرحله آموزشی
- آزمون‌های قفل‌شونده
- ماشین‌حساب‌های خورشیدی
- چت‌بات آفلاین
- localStorage
- حالت شب/روز
- لوگوی QH Technology
- PWA و Service Worker
- مناسب GitHub Pages
- بدون وابستگی اجباری به سرور

## انتشار در GitHub Pages
1. یک repository بسازید؛ پیشنهاد: `qh-solar-academy`
2. همه فایل‌های این پوشه را در ریشه repository آپلود کنید.
3. از Settings → Pages بروید.
4. در Build and deployment گزینه GitHub Actions را انتخاب کنید.
5. workflow موجود در `.github/workflows/pages.yml` به‌صورت خودکار سایت را منتشر می‌کند.

پس از انتشار، آدرس پروژه معمولاً به شکل:
`https://USERNAME.github.io/qh-solar-academy/`

خواهد بود.

## نکته
GitHub Pages سایت استاتیک است. اطلاعات حساس یا کلیدهای API را داخل کد قرار ندهید.
